#!/bin/bash

echo "Rastgele Yazdırılan Sayılar:"
for n in `seq "$1"`
do
randomNumber=$(shuf -i 1-100000 -n1)
echo "$n. Sayı: $randomNumber"
echo "$n. Sayı: $randomNumber">>$2.txt
done

gedit $2.txt
>$2.txt




