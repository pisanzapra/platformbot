#!/bin/bash
for i in {0..50..1}
do
   echo "$i $RANDOM"
done
