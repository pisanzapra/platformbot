#!/bin/bash
#BU VERİLER KAYDEDİLECEK
echo "BU PROGRAM KULLANICININ GİRDİLERİNİ KULLANARAK BİR SAYI ARALIĞINDA RASTGELE SAYILAR ÜRETİR"

echo "En Küçük Sayıyı Gİriniz:"
read minimum
echo "En Büyük Sayıyı Giriniz:"
read maximum


if [[ $maximum < $minimum ]]; then
    echo "! En Büyük Sayı En Küçük Sayıdan Küçük Olamaz !"
    exit 1
fi


diff=$(($maximum-$minimum))

if [[ $diff == 1 ]]; then
  echo "! Girdiğiniz Sayıların Farkı 1'den Büyük Olmak Zorunda !"
  exit 1
fi


randomNumber=$(( $minimum + $RANDOM % $maximum ))
echo "Bu Sayı Aralığında üretilen Rastgele Sayınız: $randomNumber"
