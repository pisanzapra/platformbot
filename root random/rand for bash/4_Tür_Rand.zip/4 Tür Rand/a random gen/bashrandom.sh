#!/bin/bash

randnumb=$(($RANDOM))
echo "Rastgele Sayı: $randnumb"
