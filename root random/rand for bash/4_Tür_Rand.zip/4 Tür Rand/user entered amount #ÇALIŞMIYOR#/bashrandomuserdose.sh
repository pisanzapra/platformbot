#!/bin/bash

echo "Bu Program Kullanıcın İstediği Miktarda Rastgele Sayı Üretir"

echo "Rastgele Üretilecek Sayı Miktarını Giriniz:"
read rand

for i in $rand
do
   echo "$i - $RANDOM"
done
